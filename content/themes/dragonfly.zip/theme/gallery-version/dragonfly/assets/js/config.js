/*================================================================*/
/*  1. Global Variables Define
/*================================================================*/
var flickr_id='YOUR_FLICKR_ID_HERE';
var instagram_accessToken='your-instagram-access-token'; // change [your-instagram-access-token] here
var instagram_clientID='your-instagram-application-clientID'; // change [your-instagram-application-clientID] here
var tapir_token = '5310b34770fda80200000009';
var search_haracter_limit = 100;
var your_latitude   = 10.839776; // Your map latitude
var your_longitude  = 106.647159; // Your map longitude